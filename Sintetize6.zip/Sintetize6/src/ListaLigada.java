public class ListaLigada {
    private Node header;
    private Node trailer;
    protected int size;
    
    public ListaLigada() {
        header = null;
        trailer = null;
        size = 0;
    }
    public int size() {
        return size;
    }
    
    public boolean isEmpty() {
        if (size == 0) {
            return true;
        } else {
            return false;
        }
    }
    
    public Node first() {
        return header;
    }
    
    public void addFirst(Node novoNum) {
        if (isEmpty()) {
            header = novoNum;
            trailer = novoNum;
        } else {
            novoNum.next = header;
            header = novoNum;
        }
        size++;
    }
    public Node last() {
        return trailer;
    }
    
    public void addLast(Node novoNum) {
        if (isEmpty()) {
            header = novoNum;
            trailer = novoNum;
        } else {
            trailer.next = novoNum;
            trailer = novoNum;
        }
        size++;
    }
    public void mostraLista() {
        Node aux = header;
        header.mostraNum();
        while(aux.next!=null) {
            aux = aux.next;
            aux.mostraNum();
        }
        System.out.println("Fim da lista!");
    }
    public void addAfter(Node novoNum, String pos) throws Exception {
        
        if (isEmpty()) 
            throw new Exception("Lista vazia");
        else {
            if (trailer.nomeNum.equals(pos)) {
                addLast(novoNum);
            } else {
                Node aux;
                for (aux = header; aux.next != null; aux = aux.next) {
                    if (aux.nomeNum.equals(pos)) {
                        novoNum.next = aux.next;
                        aux.next = novoNum;
                        size++;
                    }
                }
            }
        }
    }
    public void addBefore(Node novoNum, String pos) throws Exception {
        if (isEmpty())
            throw new Exception("Lista vazia");
        else {
            if (!header.nomeNum.equals(pos)) {
                addFirst(novoNum);
            }
             else {
                    Node aux, ant = null;
             } Node aux;
for (aux=header;!(aux.nomeNum.equals(pos));aux = aux.next) {
                Node ant = aux;
                 ant.next = novoNum;
                 novoNum.next = aux;
                 size++;
                 
             }
        }
    }
    public void remove(String animal) throws Exception {
        if (isEmpty())
            throw new Exception("Lista vazia");
        else {
            Object numero = null;
            if (header.nomeNum.equals(numero)) {
                header = header.next;
            } else {
                Node aux, ant = null;
                for(aux=header;!(aux.nomeNum.equals(numero));aux=aux.next){
                    ant = aux;
                    ant.next = aux.next;
                }
                size--;
            }
        }
    }
}
