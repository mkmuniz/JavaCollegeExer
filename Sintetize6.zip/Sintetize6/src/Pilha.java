public class Pilha extends Vetor {
    int top;
    
    public Pilha(int capacity) {
        super(capacity);
        top = -1;
    }
    public int size() {
        return super.size();
    }
    public void push(int n) throws Exception {
        top++;
        add(top, n);
    }
    public void pop() throws Exception {
        remove(top);
        top--; 
    }
    public int top() throws Exception {
        return get(top);
    }
}
