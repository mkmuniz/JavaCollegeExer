public class Queue extends ListaLigada {

    public Queue() {


        super();

    }

 

    public int size() {


        return super.size();

    }

 

    public void enqueue(int n) {


        addLast(new Node(n));

    }

 

    public void dequeue() throws Exception {


        if (size==0) {

            throw new Exception("Fila vazia... impossível desenfileirar...");

        }


        remove(first().numero);

    }

 

    public int front() throws Exception {

        // Devolve, sem desenfileirar, o primeiro elemento da fila

        if (size==0) {

            throw new Exception("Fila vazia... impossível consultar a frente");

        }

        //chama o método que retorna o primeiro elemento da lista Ligada/fila

        return first().numero;

    }

    private void remove(int numero) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}