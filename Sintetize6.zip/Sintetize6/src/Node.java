public class Node {
    int numero;
    Node next;
    Object nomeNum;
    
    public Node(int numero) {
        this.numero = numero;
        next = null;
    }
    public void mostraNum() {
        System.out.println("Número: " + numero);
    }

    class nNum {

        public nNum() {
        }
    }

    class nomeNum {

        public nomeNum() {
        }
    }
}
