public class ProjListaLigada {
    public static void main(String[] args) {
        ListaLigada numeros = new ListaLigada();
        try {
            numeros.addFirst(new Node(5));
            numeros.addFirst(new Node(3));
            numeros.addFirst(new Node(7));
            numeros.remove("");
            numeros.addFirst(new Node(9));
            numeros.mostraLista();
            numeros.remove("");
            numeros.remove("");
            numeros.remove("");
            numeros.isEmpty();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
