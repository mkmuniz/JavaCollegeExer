import java.util.Scanner;

public class NumRestantes {
    public static void main(String[] args) {
        int valor;
        int sobraQuociente;
        int restante;
        Pilha p1 = new Pilha(10);
        Scanner ler = new Scanner(System.in);
        
        try {
            valor = ler.nextInt();
                if (valor > 0) {
            
                    sobraQuociente = valor/16;
                    restante = valor%16;
                    p1.push(restante);
                    System.out.println(Integer.toHexString(p1.top()));
                        while (sobraQuociente > 0) {
                            valor = sobraQuociente/16;
                            restante = sobraQuociente%16;
                            p1.push(restante);
                            System.out.println(Integer.toHexString(p1.top()));
                            sobraQuociente = valor/16;
                            restante = valor%16;
                            p1.push(restante);
                            System.out.println(Integer.toHexString(p1.top()));
                        }
                        for(int i = 0;i<p1.size();i++) {
                            System.out.println("Número que está no topo e será desimpilhado: " + Integer.toHexString(p1.top()));
                            p1.pop();
                            System.out.println("Elementos na lista: " + p1.size());
                        }
                } else {
                    System.out.println("Número inválido");
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
        }
    }
}
