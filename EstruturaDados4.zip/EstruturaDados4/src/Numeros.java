class Numeros {
    private String tipoConteudo;
    private int quantidade;
    
    public Numeros(String tipoConteudo, int quantidade) {
        this.tipoConteudo = tipoConteudo;
        this.quantidade = quantidade;
    }

    public String getTipoConteudo() {
        return tipoConteudo;
    }

    public void setTipoConteudo(String tipoConteudo) {
        this.tipoConteudo = tipoConteudo;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
   
}
