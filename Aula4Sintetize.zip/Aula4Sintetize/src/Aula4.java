
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mikae
 */
public class Aula4 {
    public static void main (String[] args) throws ClassNotFoundException, SQLException {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            String url = "jdbc:derby://localhost:1527/sistema_academico";
            
            String usuario = "app";
            String senha = "app";
            Connection conexao;
            Scanner ler = new Scanner(System.in);
            int id_aluno;
            double nota;
            String nome;
            int i;
            conexao = DriverManager.getConnection(url, usuario, senha);
            String sql = "INSERT INTO aluno VALUES (?, ?, ?)";
            PreparedStatement stm = conexao.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            
            System.out.println("conectado!");
            for (i=0;i<4;i++) { 
                
            System.out.println("Bem-vindo! Digite o ID do aluno");
            id_aluno = ler.nextInt();
            
            System.out.println("Agora, digite o nome do aluno");
            nome = ler.next();

            System.out.println("E por fim, digite a nota do aluno");
            nota = ler.nextDouble();
            
            String SQL_Update = "UPDATE aluno SET nota=? WHERE id_aluno=?";
            stm = conexao.prepareStatement(SQL_Update);
            stm.setLong(1, id_aluno);
            stm.setString(2, nome);
            stm.setBigDecimal(3, new BigDecimal(nota));
            
            int registros = stm.executeUpdate();
            
                        while ( rs.next()) {
                id_aluno = rs.getInt("id_aluno");
                nome= rs.getString("nome");
                nota = rs.getDouble("nota");
            }
            
            stm.close();
            }
            
        } catch (SQLException ex) {
            System.out.println("Falha na conexão!");
        } 
    }
}
