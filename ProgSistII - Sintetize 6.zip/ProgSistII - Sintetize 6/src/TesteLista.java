import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class TesteLista {
    public static void main (String[] args) throws ClassNotFoundException {
            AlunoDao dao = new AlunoDao();

            Scanner res = new Scanner(System.in);
            
            Aluno alunoF = new Aluno();
            System.out.println("Hi, enter student ID: ");
            int id = res.nextInt();
            alunoF.setId(id);
            System.out.println("Now, you need enter the student name: ");
            String nome = res.next();
            alunoF.setNome(nome);
            System.out.println("At last, enter his grade: ");
            BigDecimal nota = res.nextBigDecimal();
            alunoF.setNota(nota);
            
            dao.adiciona(alunoF);
            
            System.out.println("Type the ID that you want to remove.");
            id = res.nextInt();
            
            alunoF.setId(id);
            
            dao.remove(alunoF);
            
            List<Aluno>alunos = dao.getLista();

            for (Aluno aluno : alunos) {
                System.out.println("ID: " + aluno.getId());
                System.out.println("Nome: " + aluno.getNome());
                System.out.println("Nota: " + aluno.getNota());
            }
    }
}
