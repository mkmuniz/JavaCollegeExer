
public class Node {
    String nomePasta;
    Node left, right, parent;
    
    public Node(String nomePasta) {
        this.nomePasta = nomePasta;
        left = right = parent = null;
    }
    
    public void mostraNo(){
        System.out.print(nomePasta + " - ");
    }
}
