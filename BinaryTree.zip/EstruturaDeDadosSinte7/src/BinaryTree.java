public class BinaryTree {
    Node root;
    BinaryTree() {
     root = null;
    }
    public boolean isEmpty() {
        
        if (root == null)
            return true;
        else
            return false;
    }
    public void addRoot (Node novo) throws Exception {
        if (root != null) {
            throw new Exception("The tree already has a root");
        }
        root = novo;
    }
    
    public Node root() {
        return root;
    }
    
    public boolean isInternal(Node n) {
        if (n.left!= null || n.right!= null)
            return true;
        else
            return false;
    }
    
    public boolean isLeaf(Node n) {
        
        if (n.left == null && n.right == null)
            return true;
        else
            return false;
    }
    public void addLeft(Node m, Node novo) throws Exception {
        if (hasLeft(m)) {
            throw new Exception("This node already has a left son");
        }
        m.left = novo;
        novo.parent = m;
    }
    
    public Node left(Node n) throws Exception {
        
        if(!hasLeft(n))
            throw new Exception("This node dont has a left son");
        
        return n.left;
    }
    
    public boolean hasLeft(Node n) {
        
        if (n.left != null)
            return true;
        else
            return false;
    }
    
    public void addRight(Node m, Node novo) throws Exception {
        if (hasRight(m)) {
            throw new Exception("This node already has a right son");
        }
        m.right = novo;
        novo.parent = m;
    }
    
    public Node right(Node n) throws Exception {
        
        if(!hasRight(n))
            throw new Exception("This node dont has a right son");
        
        return n.right;
    }
    
    public boolean hasRight(Node n) {
        
        if (n.right != null)
            return true;
        else
            return false;
    }
    
    public void remove(Node n) {
        if (n == root) {
            root = null;
        } else {
            if (n.parent.left == n) {
                n.parent.left=null;
            } else if (n.parent.right == n) {
                n.parent.right = null;
            }
        }
    }
    
    public void executaPreOrdem(Node no) {
        if (no == null) 
            return;
        no.mostraNo();
        executaPreOrdem(no.left);
        executaPreOrdem(no.right);
    }
    
    public void executaInOrdem(Node no) {
        if (no == null)
            return;
        executaInOrdem(no.left);
        no.mostraNo();
        executaInOrdem(no.right);
    }
    
    public void executaPosOrdem(Node no) {
        if (no == null) {
            return;
        }
        executaPosOrdem(no.left);
        executaPosOrdem(no.right);
        no.mostraNo();
    }
}
