/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mikae
 */
public class ProjArvore {
    public static void main(String[] args) throws Exception {
        BinaryTree numeros = new BinaryTree();
        Node n0 = new Node("Raiz");
        numeros.addRoot(n0);
        
        /*Após criar a variável n1, o método irá atribuir ao lado esquerdo, 
        sendo o primeiro parêmetro do nó pai e o segundo a filha.
        */
        Node n1 = new Node("5");
        numeros.addLeft(n0, n1);
        /*Após criar a variável n2, o método irá atribuir ao lado direito, 
        sendo o primeiro parêmetro do nó pai e o segundo a filha.
        */
        Node n2 = new Node("10");
        numeros.addRight(n0, n2);
        
        Node no = numeros.root();
        
        // Mostrar a raiz da arvore:
        System.out.println("Raiz: " + numeros.root().nomePasta);
        
        //Os nós serão apresentados em ordem de raiz > esquerda > direita
        System.out.println("Execução pré-ordem: ");
        numeros.executaPreOrdem(no);
        
        //Os nós serão apresentados em ordem de esquerda > raiz > direita
        System.out.println("\nExecução em ordem: ");
        numeros.executaInOrdem(no);
        
        //Os nós serão apresentados em ordem de esquerda > direita > raiz
        System.out.println("\nExecução pós-ordem");
        numeros.executaPosOrdem(no);
        
        
        /* Como cada nó possui sua variável única, podemos usar o método 
        remove() especificando o único parâmetro do node que queremos remover*/
        System.out.println("\nEliminando o nó da direita...");
        numeros.remove(n2);
        
        /* Agora, todas execuções vão apresentar a árvore sem o nó da 
        direita que foi removido anterioramente */
        System.out.println("Execução pré-ordem: ");
        numeros.executaPreOrdem(no);
        
        System.out.println("\nExecução em ordem: ");
        numeros.executaInOrdem(no);
        
        //Os nós serão apresentados em ordem de esquerda > direita > raiz
        System.out.println("\nExecução pós-ordem");
        numeros.executaPosOrdem(no);
        
    }
}
