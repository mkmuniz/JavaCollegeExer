
package SintetizeProg;

import SintetizeProg.Aluno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AlunoDao {
    private Connection connection;
    
    public AlunoDao() throws ClassNotFoundException {
        this.connection = new ConnectionFactory().getConnection();
    }
    public void adiciona(Aluno aluno) {
        String sql = "INSERT INTO aluno VALUES (?, ?, ?)";
        try {
            PreparedStatement stm = this.connection.prepareStatement(sql);
            stm.setLong(1,aluno.getId());
            stm.setString(2,aluno.getNome());
            stm.setBigDecimal(3,aluno.getNota());
            
            stm.execute();
            stm.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
     public List<Aluno> getLista() {
      try {
          List<Aluno> alunos = new ArrayList<>();
          PreparedStatement stmt;
          stmt = this.connection.
                  prepareStatement("select * from aluno");
          try (ResultSet rs = stmt.executeQuery()) {
              while (rs.next()) {
                  
                  Aluno aluno = new Aluno();
                  aluno.setId(rs.getInt("ID_ALUNO"));
                  aluno.setNome(rs.getString("NOME"));
                  aluno.setNota(rs.getBigDecimal("NOTA"));
                  
                  alunos.add(aluno);
              }
          }
          stmt.close();
          return alunos;
      } catch (SQLException e) {
          throw new RuntimeException(e);
      }
    }
     public void remove(Aluno aluno) {
            try {
                PreparedStatement stmt = connection.prepareStatement("delete " +
                        "from aluno where id_aluno=?");
                stmt.setLong(1, aluno.getId());
                stmt.execute();
                stmt.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
     public static void main(String[] args) throws SQLException {
     }
}