/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SintetizeProg;

import SintetizeProg.Aluno;
import com.google.gson.Gson;
import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author mikae
 */
@Path("generic")
public class OlaMundo {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of OlaMundo
     */
    public OlaMundo() {
    }

    /**
     * Retrieves representation of an instance of Pratique.OlaMundo
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getText() {
        int valor1 = 5;
        int valor2 = 5;
        int multiplicacao = valor1 * valor2;
        return "Resultado: " + multiplicacao;
    }
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("aluno/") // anotação pra representar o path do caminho
    public String getAlunos() throws ClassNotFoundException {
        AlunoDao dao = new AlunoDao();
        List<SintetizeProg.Aluno> listaAlunos = dao.getLista();
        String listaJSON="";
        
        for (Aluno aluno: listaAlunos) {
                listaJSON+="ID: " + aluno.getId()+ " Nome: " + 
                        aluno.getNome()+" Nota: " + aluno.getNota();
        }
        return listaJSON;
    }
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("aluno/{nome}") // anotação pra representar o path do caminho
    public String getAluno(@PathParam("nome") String nome) throws ClassNotFoundException {
        AlunoDao dao = new AlunoDao();
        List<SintetizeProg.Aluno> listaAlunos = dao.getLista();
        String listaJSON="";
        System.out.println(nome);
        Gson gson = new Gson();
        
        return gson.toJson(listaAlunos);
    }
    @GET
    @Path("aluno/remove/{id}") // anotação pra representar o path do caminho

    public void remove(@PathParam("id") int id) throws ClassNotFoundException {
        
        Aluno aluno = new Aluno();
        aluno.remove(id);
    }
}