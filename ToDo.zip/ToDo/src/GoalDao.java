
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class GoalDao {
    private Connection connection;
    
    public GoalDao() throws ClassNotFoundException {
        this.connection = new ConnectionFactory().getConnection();
    }
    public void adiciona(Goal goal) {
        String sql = "INSERT INTO LIST VALUES (?, ?, ?)";
        try {
            PreparedStatement stm = this.connection.prepareStatement(sql);
            stm.setString(1,goal.getGoal());
            stm.setString(2,goal.getHours());
            stm.setString(3,goal.getDays());
            
            stm.execute();
            stm.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
     public static void main(String[] args) throws SQLException {
     }
}
