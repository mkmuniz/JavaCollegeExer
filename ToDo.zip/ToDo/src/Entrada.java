
import java.util.Scanner;

public class Entrada {
    public static void main(String args[]) {
        Scanner read = new Scanner(System.in);
        String goal;
        int y;
        
        System.out.println("Hello, how many tasks you'd like to do today?");
        y = read.nextInt();

        for (int i = 1;i<y;i++) {
            System.out.println("Now, enter your " + i + "º task to do");
            
        }
    }
}
