
import java.math.BigDecimal;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import static javax.print.attribute.Size2DSyntax.MM;

public class Adiciona {
    public static void main (String[] args) throws ClassNotFoundException, ParseException {
            Goal goal = new Goal();
            Scanner res = new Scanner(System.in);
            System.out.println("Hi, enter your goal ");
            String goa = res.next();
            goal.setGoal(goa);
            System.out.println("How manu hours to this task?");
            String hour = res.next();
            goal.setHours(hour);
            System.out.println("Date in format dd/MM/yyyy");
            String data = res.next();
            goal.setDays(data);

            GoalDao dao = new GoalDao();
            dao.adiciona(goal);
    }
}
