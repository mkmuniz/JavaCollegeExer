
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */

    /**
     *
     * @author mikae
     */
    public class testeTudo {
        public static void main (String args[]) throws Exception {
            
            Queue<String> f1 = new LinkedList<String>();
            String nome;
            Scanner ler = new Scanner(System.in);
            
            System.out.println("What's Up! Digite o primeiro nome: ");
            nome = ler.next();
            f1.offer(nome);
            
            try {
                for (int i = 0;i<3;i++) {
                    System.out.println("Agora, digite mais um nome: ");
                    nome = ler.next();
                    f1.offer(nome);
                }
                
            System.out.println("Primeira pessoa da filha : " + f1.peek());
            System.out.println("Total de pessoas na fila: " + f1.size());
            
            System.out.println("Digite mais um nome: ");
            nome = ler.next();
            f1.offer(nome);
            
            System.out.println("Primeira pessoa da fila: " + f1.peek());
            System.out.println("Total de pessoas na fila: " + f1.size());
            
            System.out.println("Agora, iremos reverter, aguarde...");
            Collections.reverse((List<?>) f1);
            
            System.out.println("Pronto, primeira pessoa da fila: " + f1.peek());
            System.out.println("Total de pessoas na fila: " + f1.size());
            
            } catch (Exception e) {
                System.out.println (e.getMessage());
            }
        }
    }
