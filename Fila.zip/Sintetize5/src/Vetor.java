public class Vetor {
    protected String[ ] A;
    private int capacity;
    private int size;
    
    public Vetor(int capacity) {
        A = new String[capacity];
    this.size = 0;
    this.capacity = capacity;
    }
    public boolean isEmpty() {
        if (size <= -1) {
            return true;
        } else {
            return false;
        }
    }
    public int size() {
        return size;
    }
    public String get(int i) throws Exception {
        if (i<0 || i>=size) {
            throw new Exception ("Posição Invalida!");
        }
        return A[i];
    }
    public void set(int i, String n) throws Exception {
        if (isEmpty()) {
           throw new Exception("Lista vazia");
        }
        A[i] = n;
    }
    public void add(int i, String n) throws Exception {
        if (size == A.length) {
            throw new Exception("Lista cheia!");
        }
        for (int j = size - 1; j >= i; j--) {
            A[j + 1] = A[j];
        }
        A[i] = n;
        size++;
    }
    public void remove(int i) throws Exception {
        if (isEmpty()) {
            throw new Exception("Lista vazia!");
        }
        for (int j = i; j <= size - 1; j++) {
            A[j] = A[j + 1];
        }
        size--;
    }
    public void search(int n) {
        
    }
 }
