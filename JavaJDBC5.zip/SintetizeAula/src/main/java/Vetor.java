public class Vetor {
    private Aluno[] A;
    private int capacity;
    private int size;
    
    public boolean isEmpty() {
        if (size==0) {
            return true;
        } else
            return false;
    }
    public int size() {
        return size;
    }
    public Aluno get(int i) throws Exception {
        if(isEmpty()) throw new Exception ("Lista está vazia!");
        if (i>=size()) throw new Exception ("Posição não existe!");
        return A[i];
    }
    public void set(int i, Aluno n) throws Exception {
        if(isEmpty()) throw new Exception ("Lista está vazia!");
        if (i>=size()) throw new Exception ("Posição não existe!");
        A[i]=n;
    }
    public void locPlace (Aluno n) throws Exception {
        if (size==0)
            add(0,n);
        else
            for (int i=0;i<size;i++)
                if (n.getCodigo()>=A[i].getCodigo()){
                    add(i,n);
                    break;
                }
    }
    public void add(int i, Aluno n) throws Exception {
        if (size==A.length)
            size--;
        for (int j=size-1;j>=i;j--){
            A[j+1]=A[j];
            A[i]=n;
            size++;
        }
    }
    public void remove(int i) throws Exception {
        if (isEmpty()) throw new Exception ("Lista esta vazia!");
        if (i>=size) throw new Exception ("Posição está invalida!");
        for(int j=i;j<=size;j++)
            A[j]=A[j+1];
        size--;
    }
    public int search (Aluno n) {
        for (int i=0;i<A.length;i++)
            if (A[i].getNome().equals(n.getNome()))
                return i;
        return -1;
    }
}