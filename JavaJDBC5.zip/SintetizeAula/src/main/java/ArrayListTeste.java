import java.util.ArrayList;
public class ArrayListTeste {
    public static void main(String[] args) {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        ArrayList<String> Aluno = new ArrayList<String>();
        
        Aluno.add(5, "Mikael");
        
    }
}
