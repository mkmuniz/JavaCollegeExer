/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SintetizeProg;

import Pratique.Aluno;
import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author mikae
 */
@Path("generic")
public class OlaMundo {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of OlaMundo
     */
    public OlaMundo() {
    }

    /**
     * Retrieves representation of an instance of Pratique.OlaMundo
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getText() {
        int valor1 = 5;
        int valor2 = 5;
        int multiplicacao = valor1 * valor2;
        return "Resultado: " + multiplicacao;
    }
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("aluno/{nome}") // anotação pra representar o path do caminho
    public String getAluno(@PathParam("nome") String nome) throws ClassNotFoundException {
        AlunoDao dao = new AlunoDao();
        List<Aluno> listaAlunos = dao.getLista();
        String listaJSON="";
        
        for (Aluno aluno: listaAlunos)
            listaJSON+="ID: " + aluno.getId()+ " Nome: " + aluno.getNome();
        return listaJSON;
    }
}