import java.util.List;
import java.util.function.Function;

public class TesteLista {
    public static void main (String[] args) throws ClassNotFoundException {
            AlunoDao dao = new AlunoDao();

            List<Aluno>alunos = dao.getLista();

            alunos.stream().map((Aluno aluno) -> {
                System.out.println("ID: " + aluno.getId());
            return aluno;
            }).map(new Function<Aluno, Aluno>() {
                @Override
                public Aluno apply(Aluno aluno) {
                    System.out.println("Nome: " + aluno.getNome());
                    return aluno;
                }
            }).forEachOrdered((aluno) -> {
                System.out.println("Nota: " + aluno.getNota());
            });
    }
}
