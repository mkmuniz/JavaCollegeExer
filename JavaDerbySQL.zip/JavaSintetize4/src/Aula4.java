
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.Statement;

public class Aula4 {
    public static void main (String[] args) throws ClassNotFoundException, SQLException {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            String url = "jdbc:derby://localhost:1527/sistema_academico";
            
            String usuario = "app";
            String senha = "app";
            
            Connection conexao;
            Scanner ler = new Scanner(System.in);
            conexao = DriverManager.getConnection(url, usuario, senha);
            String sql = "insert into aluno " +
                  "(nome,nota) " +
                  "values (?,?)";
            String sql2 = "SELECT * from aluno";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            PreparedStatement stm = conexao.prepareStatement(sql2);
            
            int id_aluno;
            int n;
            BigDecimal nota;
            String nome = null;
            
            System.out.println("Olá, digite o numero de alunos que você deseja inserir: ");
            n = ler.nextInt();
            
            for (int i = 0;i<n;i++) {
                System.out.println("Olá, digite o ID do aluno: ");
                id_aluno = ler.nextInt();

                System.out.println("Agora, você precisa digitar o nome do aluno: ");
                nome = ler.next();

                System.out.println("E por fim, digite a sua nota:  ");
                nota = ler.nextBigDecimal();
                
                stmt.setString(1, nome);
                stmt.setBigDecimal(2, nota);
                
                int registros = stmt.executeUpdate();
                
                stmt.execute();
                stmt.close();
                
                System.out.println("Finalizado! Nome: "+nome+ " Nota: "+nota);
                
                stmt = conexao.prepareStatement(sql);
            }
            
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                nome = rs.getString("nome");
                nota = rs.getBigDecimal("nota");
                System.out.println("nome: "+nome+ " nota: "+nota);
            }
            
            }
             catch (SQLException ex){
            System.out.println("Connection failed! "+ex);
        } 
    }
}
